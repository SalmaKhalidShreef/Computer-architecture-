import java.util.Hashtable;

public class registerFile {
     Hashtable<String,String> registers;
  public registerFile( ) {
      this.registers= new Hashtable<String,String>();
      for (int i = 0; i < 64; i++) {
          registers.put("R" + i, "00000000");


      }


  }}