public class dataMemory {
    String[] memory;
    public dataMemory(){
        memory = new String [2048] ;
    }
}
