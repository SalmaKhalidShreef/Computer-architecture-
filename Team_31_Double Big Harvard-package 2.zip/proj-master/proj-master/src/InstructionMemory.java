public class InstructionMemory {
    String[] memory;
    int pointer=0;

    public InstructionMemory(){
      memory = new String [1024] ;
    }
    public void parse(String inst){}

}
