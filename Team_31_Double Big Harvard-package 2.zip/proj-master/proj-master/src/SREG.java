public class SREG {
    boolean C ; // Carry Flag
    boolean V ; // Two’s Complement Overflow Flag
    boolean N ; // Negative Flag
    boolean S ; // Sign Flag
    boolean Z ; // Zero Flag
    String name;
    String content;
    public SREG(String name){
      this.name = name;
        updatereg();


    }
    public void updatereg(){
        this.content="000";

        if (C==true)
            content+="1";
        else {
            content+="0";
        }
        if (V==true)
            content+="1";
        else {
            content+="0";
        }
        if (N==true)
            content+="1";
        else {
            content+="0";
        }
        if (S==true)
            content+="1";
        else {
            content+="0";
        }
        if (Z==true)
            content+="1";
        else {
            content+="0";
        }



        }


    }


