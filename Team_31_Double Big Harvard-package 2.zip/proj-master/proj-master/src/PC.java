public class PC  {
    String content;
    String name;

    public PC(String name) {
        this.name= name;
        content="0000000000000000";
    }

    public void Increment (){

}

}
